# OIBSIP_TASK1
Landing Page


Our landing page is a targeted, aesthetically pleasing website created to accomplish a particular objective, like increasing conversions, promoting a product, or producing leads.


A fully responsive landing page guarantees smooth operation on a range of screens and devices, offering the best possible user experience on PCs, tablets, and smartphones.

With the help of HTML and CSS, the project was successfully finished, creating a visually appealing and incredibly useful website.

