# OIBSIP_TASK-2
Personal Portfolio 



The primary purpose of a portfolio website is to showcase My work, skills and talent. Ensure portfolio section is visually appealing, easy to navigate, and highlights your best projects

This portfolio effectively showcases your skills and projects, making a strong impact on visitors\

Reflect your personal brand , including your logo, color scheme, and tone of voice, to create a memorable impression.

Using HTML and CSS, ensuring a stunning and functional design.
