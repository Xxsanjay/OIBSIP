# OIBSIP_TASK-3
Temperature converter

Temperature Converter website ,A user-friendly temperature converter website designed to convert temperatures between Celsius, Fahrenheit, and Kelvin.

Intuitive design for easy input and conversion of temperatures, Instant conversion results as you type, Seamless performance across various devices and screen sizes.

The Temperature converter website has been successfully completed using HTML,CSS and Javascript.
